using NUnit.Framework;
using PlaywrightSharp;
using System;
using System.Threading.Tasks;

namespace PlaywrightSharpDemo
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task Test1()
        {
            using var playwright = await Playwright.CreateAsync();

            LaunchOptions launchOptions = new LaunchOptions()
            {
                Headless = false,
                Devtools = true,
                SlowMo = 2000
            };

            await using var browser = await playwright.Webkit.LaunchAsync(launchOptions);

            var contextOptions = playwright.Devices["iPhone 11 Pro"].ToBrowserContextOptions();
            contextOptions.Locale = "en-US";
            contextOptions.Geolocation = new Geolocation { Longitude = 12.492507m, Latitude = 41.889938m };
            contextOptions.Permissions = new[] { ContextPermission.Geolocation };

            var context = await browser.NewContextAsync(contextOptions);
            var page = await context.NewPageAsync();
            await page.GoToAsync("https://maps.google.com");
            await page.ClickAsync("text='Your location'"); //
            await page.ScreenshotAsync("colosseum-iphone.png");
        }


        [Test]
        public async Task NetworkInterception()
        {
            using var playwright = await Playwright.CreateAsync();

            LaunchOptions launchOptions = new LaunchOptions()
            {
                Headless = false,
            };
            await using var browser = await playwright.Firefox.LaunchAsync(launchOptions);

            var context = await browser.NewContextAsync();
            var page = await context.NewPageAsync();
            // Log and continue all network requests
            await page.RouteAsync("**/*", (route, _) =>
            {
                if (route.Request.ResourceType == ResourceType.Image)
                    route.AbortAsync();
                else
                    route.ContinueAsync();
            });

            await page.GoToAsync("http://amazon.com");
        }
    }
}