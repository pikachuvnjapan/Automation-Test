import {it} from './fixtureparam'

it('Browser version test', async ({bro}) => {
    console.log(bro)
});