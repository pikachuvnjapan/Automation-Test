package com.ea;

import com.microsoft.playwright.*;

public class Main {

    public static void main(String[] args) throws Exception {
        //Navigation();
        NetworkInteception();
    }

    private static void Navigation() throws Exception {
        Playwright playwright = Playwright.create();
        BrowserType browserType = playwright.chromium();

        BrowserType.LaunchOptions launchOptions = new BrowserType.LaunchOptions();
        launchOptions.devtools = true;
        launchOptions.headless = false;

        Browser browser = browserType.launch(launchOptions);

//        Browser.NewContextOptions newContextOptions = new Browser.NewContextOptions();
//        newContextOptions.withDevice(playwright.devices().get("iPhone 11 pro Max"));
        BrowserContext context = browser.newContext();
        Page page = context.newPage();

        page.navigate("http://todomvc.com");
        browser.close();
        playwright.close();
    }

    public static void NetworkInteception() throws Exception {
        Playwright playwright = Playwright.create();
        BrowserType browserType = playwright.chromium();

        BrowserType.LaunchOptions launchOptions = new BrowserType.LaunchOptions();
        launchOptions.devtools = true;
        launchOptions.headless = false;

        Browser browser = browserType.launch(launchOptions);

        BrowserContext context = browser.newContext();
        Page page = context.newPage();

        page.route("**/*", route -> {
            if(route.request().resourceType().equalsIgnoreCase("image"))
                route.abort();
            else
                route.continue_();
        });


        page.navigate("http://amazon.com");
        browser.close();
        playwright.close();
    }

    public static void NetworkInteceptionAndGetEvents() throws Exception {
        Playwright playwright = Playwright.create();
        BrowserType browserType = playwright.chromium();

        BrowserType.LaunchOptions launchOptions = new BrowserType.LaunchOptions();
        launchOptions.devtools = true;
        launchOptions.headless = false;

        Browser browser = browserType.launch(launchOptions);

        BrowserContext context = browser.newContext();
        Page page = context.newPage();


        page.navigate("http://amazon.com");
        browser.close();
        playwright.close();
    }
}
