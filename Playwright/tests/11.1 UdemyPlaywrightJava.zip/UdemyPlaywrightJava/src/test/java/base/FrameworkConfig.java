package base;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class FrameworkConfig {

    public static Page LocalPage;
    public static Playwright Playwright;
    public static Browser Browser;

}
