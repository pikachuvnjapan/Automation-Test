package config;

public class Settings {

    public static String BrowserName;
    public static boolean Headless;
    public static boolean DevTools;
    public static String DeviceEmulationType;
    public static String Locale;
}
